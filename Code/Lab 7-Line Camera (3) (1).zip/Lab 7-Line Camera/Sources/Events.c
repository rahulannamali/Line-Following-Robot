/* ###################################################################
**     Filename    : Events.c
**     Project     : Lab 7-Line Camera
**     Processor   : MKL25Z128VLK4
**     Component   : Events
**     Version     : Driver 01.00
**     Compiler    : GNU C Compiler
**     Date/Time   : 2023-03-31, 17:56, # CodeGen: 19
**     Abstract    :
**         This is user's event module.
**         Put your event handler code here.
**     Contents    :
**         PWM1_OnEnd0     - void PWM1_OnEnd0(void);
**         PWM1_OnEnd      - void PWM1_OnEnd(void);
**         TI1_OnInterrupt - void TI1_OnInterrupt(void);
**         Cpu_OnNMIINT    - void Cpu_OnNMIINT(void);
**
** ###################################################################*/
/*!
** @file Events.c
** @version 01.00
** @brief
**         This is user's event module.
**         Put your event handler code here.
*/         
/*!
**  @addtogroup Events_module Events module documentation
**  @{
*/         
/* MODULE Events */

#include "Cpu.h"
#include "Events.h"

#ifdef __cplusplus
extern "C" {
#endif 

volatile int count = 0;
volatile bool snoop_lion = FALSE;//false is low SI, true is HIGGGGGHHH(smoke weed everyday)
uint16_t digit;
volatile int bits[200];
uint16_t mid;
uint16_t size;
int ratio = 5500;
int middle = 0;
int error = 0;
int prev_error = 0;
int start = 0;
int stoppawilly = 0;
char mc1;
char mc2;

//int16_t cod = 2333;
//volatile char c = "_";
//volatile char d = "I";
/* User includes (#include below this line is not maintained by Processor Expert) */

/*
** ===================================================================
**     Event       :  PWM1_OnEnd (module Events)
**
**     Component   :  CLK [PWM]
**     Description :
**         This event is called when the specified number of cycles has
**         been generated. (Only when the component is enabled -
**         <Enable> and the events are enabled - <EnableEvent>). The
**         event is available only when the <Interrupt service/event>
**         property is enabled and selected peripheral supports
**         appropriate interrupt.
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/
void PWM1_OnEnd(void)
{
  /* Write your code here ... */
	//Bit1_SetVal();
	//AD1_Measure(0);
	if(count >= 172)
	{
		for(int i = 1; i < count; i++)
		{
			if(bits[i-1] == 1 && bits[i] == 0)
			{
				start = i;
			}
			else if(bits[i-1] == 0 && bits[i] == 1)
			{
				stoppawilly = i-1;
				if((stoppawilly-start) > 5)
				{
					break;
				}
			}
			/*
			else if(i == count-1)
			{
				if((bits[i] == 0))
				start = 0;
				stoppawilly = 172;
			}
			*/
		}
		middle = stoppawilly-start;
		middle = middle/2;
		middle = middle + start;
		//middle = ((stoppawilly - start)/2) + start;
		mc1 =(middle/10);
		mc2 =(middle%10);
		error = 86-middle;
		ratio = error *52 + 5500;
		if(ratio > 8000)
		{
			//turn right
			ratio = 7000;
		}
		else if(ratio < 3839)
		{
			//turn left
			ratio = 1000;
		}
		PWM1_SetRatio16(1-ratio);
		TI1_Enable();
		count = 0;
	}
	else
	{
		AD1_Measure(0);
	}
	count++;
}

/*
** ===================================================================
**     Event       :  TI1_OnInterrupt (module Events)
**
**     Component   :  TI1 [TimerInt]
**     Description :
**         When a timer interrupt occurs this event is called (only
**         when the component is enabled - <Enable> and the events are
**         enabled - <EnableEvent>). This event is enabled only if a
**         <interrupt service/event> is enabled.
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/

void TI1_OnInterrupt(void)
{
	if(snoop_lion)
	{
		//Make SI Low
		Bit1_ClrVal();
		//SI_ClrVal(SI_Init);
		//Bit1_ClrVal();
		snoop_lion = FALSE;
		TI1_Disable();
	}
	else
	{
		//Make SI High(Bit1IO gives 100% correct output), SI is "untested"/not 100%
		//SI_SetVal(SI_Init);
		Bit1_SetVal();
		//Bit1_SetVal();
		snoop_lion = TRUE;
	}
}

/*
** ===================================================================
**     Event       :  Cpu_OnNMIINT (module Events)
**
**     Component   :  Cpu [MKL25Z128LK4]
*/
/*!
**     @brief
**         This event is called when the Non maskable interrupt had
**         occurred. This event is automatically enabled when the [NMI
**         interrupt] property is set to 'Enabled'.
*/
/* ===================================================================*/
void Cpu_OnNMIINT(void)
{
  /* Write your code here ... */
}

/*
** ===================================================================
**     Event       :  TI2_OnInterrupt (module Events)
**
**     Component   :  TI2 [TimerInt_LDD]
*/
/*!
**     @brief
**         Called if periodic event occur. Component and OnInterrupt
**         event must be enabled. See [SetEventMask] and [GetEventMask]
**         methods. This event is available only if a [Interrupt
**         service/event] is enabled.
**     @param
**         UserDataPtr     - Pointer to the user or
**                           RTOS specific data. The pointer passed as
**                           the parameter of Init method.
*/
/* ===================================================================*/
/*
void TI2_OnInterrupt(LDD_TUserData *UserDataPtr)
{
	if(snoop_lion)
	{
		//Make SI Low
		Bit1_ClrVal();
		SI_ClrVal(UserDataPtr);
		//Bit1_ClrVal();
		snoop_lion = FALSE;
		TI2_Disable(UserDataPtr);
	}
	else
	{
		//Make SI High
		SI_SetVal(UserDataPtr);
		Bit1_SetVal();
		//Bit1_SetVal();
		snoop_lion = TRUE;
	}

}
*/
/*
** ===================================================================
**     Event       :  AS2_OnError (module Events)
**
**     Component   :  AS2 [AsynchroSerial]
**     Description :
**         This event is called when a channel error (not the error
**         returned by a given method) occurs. The errors can be read
**         using <GetError> method.
**         The event is available only when the <Interrupt
**         service/event> property is enabled.
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/
void AS2_OnError(void)
{
  /* Write your code here ... */
}

/*
** ===================================================================
**     Event       :  AS2_OnTxChar (module Events)
**
**     Component   :  AS2 [AsynchroSerial]
**     Description :
**         This event is called after a character is transmitted.
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/
void AS2_OnTxChar(void)
{
  /* Write your code here ... */
}

/*
** ===================================================================
**     Event       :  AS2_OnFreeTxBuf (module Events)
**
**     Component   :  AS2 [AsynchroSerial]
**     Description :
**         This event is called after the last character in output
**         buffer is transmitted.
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/
void AS2_OnFreeTxBuf(void)
{
  /* Write your code here ... */
}

/*
** ===================================================================
**     Event       :  AD1_OnEnd (module Events)
**
**     Component   :  AD1 [ADC]
**     Description :
**         This event is called after the measurement (which consists
**         of <1 or more conversions>) is/are finished.
**         The event is available only when the <Interrupt
**         service/event> property is enabled.
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/
int c = 0;
void AD1_OnEnd(void)
{
  /* Write your code here ... */
	AD1_GetValue16(&digit);
	if(digit >= 29788 && digit <= 49647)
	{
		bits[count] = 0;
		AS2_SendChar('0');
	}

	else
	{
		bits[count] = 1;
		AS2_SendChar('1');
	}
	AS2_SendChar('\n');
	/*
	AS2_SendChar('\n');
	AS2_SendChar('\n');
	AS2_SendChar(' ');
	AS2_SendChar(' ');
	AS2_SendChar(' ');
	AS2_SendChar(' ');
	AS2_SendChar(' ');
	AS2_SendChar(' ');
	AS2_SendChar(' ');
	AS2_SendChar(' ');
	AS2_SendChar(' ');
	AS2_SendChar(' ');
	AS2_SendChar(' ');
	AS2_SendChar(' ');
	AS2_SendChar(' ');
	AS2_SendChar(' ');
	AS2_SendChar(' ');
	AS2_SendChar(' ');
	AS2_SendChar(' ');
	AS2_SendChar(' ');
	AS2_SendChar(' ');
	AS2_SendChar(' ');
	AS2_SendChar(' ');
	AS2_SendChar(' ');

	if(c >= 129)
	{
		AS2_SendChar('Z');
		c = 0;
	}
	*/
}

/*
** ===================================================================
**     Event       :  AD1_OnCalibrationEnd (module Events)
**
**     Component   :  AD1 [ADC]
**     Description :
**         This event is called when the calibration has been finished.
**         User should check if the calibration pass or fail by
**         Calibration status method./nThis event is enabled only if
**         the <Interrupt service/event> property is enabled.
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/
void AD1_OnCalibrationEnd(void)
{
  /* Write your code here ... */
}

/*
** ===================================================================
**     Event       :  PWM1_OnEnd0 (module Events)
**
**     Component   :  PWM1 [PWM]
**     Description :
**         This event is called when the specified number of cycles has
**         been generated. (Only when the component is enabled -
**         <Enable> and the events are enabled - <EnableEvent>). The
**         event is available only when the <Interrupt service/event>
**         property is enabled and selected peripheral supports
**         appropriate interrupt.
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/
void PWM1_OnEnd0(void)
{
  /* Write your code here ... */
	//PWM1_SetDutyUS(ratio);
	//PWM1_SetDutyMS(cod);

}

/*
** ===================================================================
**     Event       :  ServoUpdate_OnInterrupt (module Events)
**
**     Component   :  ServoUpdate [TimerInt]
**     Description :
**         When a timer interrupt occurs this event is called (only
**         when the component is enabled - <Enable> and the events are
**         enabled - <EnableEvent>). This event is enabled only if a
**         <interrupt service/event> is enabled.
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/
void ServoUpdate_OnInterrupt(void)
{
  /* Write your code here ... */
	//PWM1_SetRatio16(1-ratio);
	/*
	AS2_SendChar(ratio/10000 % 10 + 48);
	AS2_SendChar(ratio/1000 % 10 + 48);
	AS2_SendChar(ratio/100 % 10 + 48);
	AS2_SendChar(ratio/10 % 10 + 48);
	AS2_SendChar(ratio % 10 + 48);
	AS2_SendChar('\n');
	AS2_SendChar('\n');
	AS2_SendChar('\n');
	AS2_SendChar('\n');
	*/
	//ratio = ratio + 1000;
}

/* END Events */

#ifdef __cplusplus
}  /* extern "C" */
#endif 

/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.5 [05.21]
**     for the Freescale Kinetis series of microcontrollers.
**
** ###################################################################
*/
