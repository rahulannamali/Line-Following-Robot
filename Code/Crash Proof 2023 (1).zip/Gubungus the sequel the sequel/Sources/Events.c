/* ###################################################################
**     Filename    : Events.c
**     Project     : Projecto
**     Processor   : MKL25Z128VLK4
**     Component   : Events
**     Version     : Driver 01.00
**     Compiler    : GNU C Compiler
**     Date/Time   : 2023-04-12, 17:27, # CodeGen: 0
**     Abstract    :
**         This is user's event module.
**         Put your event handler code here.
**     Contents    :
**         Cpu_OnNMIINT - void Cpu_OnNMIINT(void);
**
** ###################################################################*/
/*!
** @file Events.c
** @version 01.00
** @brief
**         This is user's event module.
**         Put your event handler code here.
*/         
/*!
**  @addtogroup Events_module Events module documentation
**  @{
*/         
/* MODULE Events */

#include "Cpu.h"
#include "Events.h"
#include <stdio.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif 

volatile int count = 0;
volatile bool snoop_lion = FALSE;//false is low SI, true is HIGGGGGHHH(smoke weed everyday)
uint16_t digit;
volatile int bits[200];
uint16_t mid;
uint16_t size;
int ratio = 5500;
int middle = 0;
int error = 0;
int prev_error = 0;
int start = 0;
int stopBillieNow;
int crashproof;
int stoppawilly = 128;
char mc1;
char mc2;
extern int countawilly;
double velocity;
int joemr1_4 = 65535;
int joemr2_3 = 0;
int error_count = 0;
int error_state = 0;
int Error = 0;
bool forward = TRUE;
double mr1_4 = 1;
double mr2_3 = 0.98;
int max_ratio = 65535;
int bitcount = 0;
bool right = FALSE;
//int16_t cod = 2333;
//volatile char c = "_";
//volatile char d = "I";
/* User includes (#include below this line is not maintained by Processor Expert) */
/*
** ===================================================================
**     Event       :  Cpu_OnNMIINT (module Events)
**
**     Component   :  Cpu [MKL25Z128LK4]
*/
/*!
**     @brief
**         This event is called when the Non maskable interrupt had
**         occurred. This event is automatically enabled when the [NMI
**         interrupt] property is set to 'Enabled'.
*/
/* ===================================================================*/
void Cpu_OnNMIINT(void)
{
  /* Write your code here ... */
}

/*
** ===================================================================
**     Event       :  HES_TimerInt_OnInterrupt (module Events)
**
**     Component   :  HES_TimerInt [TimerInt]
**     Description :
**         When a timer interrupt occurs this event is called (only
**         when the component is enabled - <Enable> and the events are
**         enabled - <EnableEvent>). This event is enabled only if a
**         <interrupt service/event> is enabled.
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/
void HES_TimerInt_OnInterrupt(void)
{
  /* Write your code here ... */
	double tran = countawilly * 0.5; // This is the total number of transitions of the wheel
	double pi = 3.1415; // pretty obvious
	double r = 0.083; // this is the radius of the wheel in feet

	velocity = tran * pi * r; // 0.0833 is 1 inch per second in feet/s

	// transitions are based in 500 ms so the velocity is double
	// to get feet per second f/s
	velocity *= 2;


	countawilly = 0; // reset count for next checking


}

/*
** ===================================================================
**     Event       :  SI_TimerInt_OnInterrupt (module Events)
**
**     Component   :  SI_TimerInt [TimerInt]
**     Description :
**         When a timer interrupt occurs this event is called (only
**         when the component is enabled - <Enable> and the events are
**         enabled - <EnableEvent>). This event is enabled only if a
**         <interrupt service/event> is enabled.
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/
void SI_TimerInt_OnInterrupt(void)
{
  /* Write your code here ... */
	if(snoop_lion)
	{
		//Make SI Low
		SI_ClrVal();
		//SI_ClrVal(SI_Init);
		//Bit1_ClrVal();
		snoop_lion = FALSE;
		SI_TimerInt_Disable();
	}
	else
	{
		//Make SI High(Bit1IO gives 100% correct output), SI is "untested"/not 100%
		//SI_SetVal(SI_Init);
		SI_SetVal();
		//Bit1_SetVal();
		snoop_lion = TRUE;
	}
}

/*
** ===================================================================
**     Event       :  AD1_OnEnd (module Events)
**
**     Component   :  AD1 [ADC]
**     Description :
**         This event is called after the measurement (which consists
**         of <1 or more conversions>) is/are finished.
**         The event is available only when the <Interrupt
**         service/event> property is enabled.
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/
void AD1_OnEnd(void)
{
  /* Write your code here ... */
	//AS2_SendChar('\n');
	AD1_GetValue16(&digit);

	const uint16_t thresh = (3.1/3.3) * 65535;
	const uint16_t thresh2 = (1.0/3.3) * 65535;

	if(digit <= thresh && digit >= thresh2)
	{
		bits[count] = 1;
		//AS2_SendChar('1');
	}
	else
	{
		bits[count] = 0;
		//AS2_SendChar('0');
	}
}

/*
** ===================================================================
**     Event       :  AD1_OnCalibrationEnd (module Events)
**
**     Component   :  AD1 [ADC]
**     Description :
**         This event is called when the calibration has been finished.
**         User should check if the calibration pass or fail by
**         Calibration status method./nThis event is enabled only if
**         the <Interrupt service/event> property is enabled.
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/
void AD1_OnCalibrationEnd(void)
{
  /* Write your code here ... */
}

/*
** ===================================================================
**     Event       :  CLK_OnEnd (module Events)
**
**     Component   :  CLK [PWM]
**     Description :
**         This event is called when the specified number of cycles has
**         been generated. (Only when the component is enabled -
**         <Enable> and the events are enabled - <EnableEvent>). The
**         event is available only when the <Interrupt service/event>
**         property is enabled and selected peripheral supports
**         appropriate interrupt.
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/
void CLK_OnEnd(void)
{
  /* Write your code here ... */
	//Bit1_SetVal();
	//AD1_Measure(0);
	if(count == 135)
	{
		start = 0;
		//stoppawilly = 135;
		for(int i = 2; i < count; i++)
		{
			if(bits[i] == 1)
			{
				bitcount++;
			}
			if(bits[i-1] == 0 && bits[i] == 1)
			{
				start = i;
			}
			else if(bits[i-1] == 1 && bits[i] == 0)
			{
				stoppawilly = i-1;
				if((stoppawilly-start) > 5)
				{
					break;
				}
			}
			else if(i == count-1)
			{
				if(bits[i] == 1)
				{
					stoppawilly = 135;
				}
			}
		}
		middle = stoppawilly-start;
		middle = middle/2;
		middle = middle + start;

		//middle = ((stoppawilly - start)/2) + start;

		error = 67-middle;
		if(error > 0)
		{
			right = TRUE;
		}
		else
		{
			right = FALSE;
		}



		//
		// Start
		// this is for the velocity controller
		//


		// Proportional controller
		int kp = 1;
		int chg = 0;// this is the change  for the motors ratio inputs
		chg = kp * Error;// the error is always negative
		/*


		if(abs(error) > 30)
		{
			mr1_4 = 1;
			mr2_3 = .9;
			forward = FALSE;
		}
		else
		{
			mr1_4 = .9;
			mr2_3 = 1;
			forward = TRUE;
		}
		if(mr1_4 < 1 && mr1_4 > .3)
		{
			mr2_3 = 1;
			mr1_4 += chg;
		}
		if(mr2_3 < 1 && mr2_3 > .3)
		{
			mr1_4 = 1;
			mr2_3 += chg;
		}

*/

	//	  	 motor controller variables
		/*
		if(forward)
		{
			 MC3_SetRatio16(mr2_3*max_ratio);
			 MC2_SetRatio16(mr2_3*max_ratio);
			 MC1_SetRatio16(mr1_4*max_ratio);
			 MC4_SetRatio16(mr1_4*max_ratio);
		}
		else
		{
			 MC1_SetRatio16(mr1_4*max_ratio);
			 MC4_SetRatio16(mr1_4*max_ratio);
			 MC3_SetRatio16(mr2_3*max_ratio);
			 MC2_SetRatio16(mr2_3*max_ratio);
		}
		*/




		//
		//End of velocity
		//


		//
		// This is for the servo
		//
		ratio = 5500-error*15 + (prev_error - error) * 1;//changed from error *25
		prev_error = error; //This is for the derivative part of PID
		//hard code test of servo
		/*
		if(ratio > 7000)
		{
			//turn right
			ratio = 7000;
		}
		else if(ratio < 1000)
		{
			//turn left
			ratio = 1000;
		}
		*/
		if(bitcount < 5)
		{
			if(right)
			{
				Servo_SetRatio16(1-7000);
			}
			else
			{
				Servo_SetRatio16(1-1000);
			}
		}
		else
		{
			Servo_SetRatio16(1-ratio);
		}
		bitcount = 0;
	}
	else if (count >= 150)
	{
		SI_TimerInt_Enable();
		count = 0;
		/*
		if(bitcount < 5 || bitcount > 50)
		{
			mr1_4 = 1;
			mr2_3 = .9;
			forward = FALSE;
		}
		else
		{
			mr1_4 = .9;
			mr2_3 = 1;
			forward = TRUE;
		}
		*/
		//bitcount = 0;
		return;
	}
	else
	{
		AD1_Measure(0);
	}
	count++;
}


//
// This is the start of the motor controller
//
/*
** ===================================================================
**     Event       :  MC4_OnEnd (module Events)
**
**     Component   :  MC4 [PWM]
**     Description :
**         This event is called when the specified number of cycles has
**         been generated. (Only when the component is enabled -
**         <Enable> and the events are enabled - <EnableEvent>). The
**         event is available only when the <Interrupt service/event>
**         property is enabled and selected peripheral supports
**         appropriate interrupt.
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/
void MC4_OnEnd(void)
{
  /* Write your code here ... */
	//
	//used to be ptc4

	// pcb port is now ptc2
	 MC4_SetRatio16(mr1_4*max_ratio);
}


/*
** ===================================================================
**     Event       :  MC3_OnEnd (module Events)
**
**     Component   :  MC3 [PWM]
**     Description :
**         This event is called when the specified number of cycles has
**         been generated. (Only when the component is enabled -
**         <Enable> and the events are enabled - <EnableEvent>). The
**         event is available only when the <Interrupt service/event>
**         property is enabled and selected peripheral supports
**         appropriate interrupt.
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/
void MC3_OnEnd(void)
{
  /* Write your code here ... */
	//
	//no chang in port
	 MC3_SetRatio16(mr2_3*max_ratio);
}

/*
** ===================================================================
**     Event       :  MC2_OnEnd (module Events)
**
**     Component   :  MC2 [PWM]
**     Description :
**         This event is called when the specified number of cycles has
**         been generated. (Only when the component is enabled -
**         <Enable> and the events are enabled - <EnableEvent>). The
**         event is available only when the <Interrupt service/event>
**         property is enabled and selected peripheral supports
**         appropriate interrupt.
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/
void MC2_OnEnd(void)
{
  /* Write your code here ... */
	//
	//used to be ptc2

	//port pcb:
	// ptc4

	 MC2_SetRatio16(mr2_3*max_ratio);
}

/*
** ===================================================================
**     Event       :  MC1_OnEnd (module Events)
**
**     Component   :  MC1 [PWM]
**     Description :
**         This event is called when the specified number of cycles has
**         been generated. (Only when the component is enabled -
**         <Enable> and the events are enabled - <EnableEvent>). The
**         event is available only when the <Interrupt service/event>
**         property is enabled and selected peripheral supports
**         appropriate interrupt.
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/
void MC1_OnEnd(void)
{
  /* Write your code here ... */

	//
	// for the pcb:
	// no chang needed
	//PtC1



	 MC1_SetRatio16(mr1_4*max_ratio);
}

/* END Events */

#ifdef __cplusplus
}  /* extern "C" */
#endif 

/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.5 [05.21]
**     for the Freescale Kinetis series of microcontrollers.
**
** ###################################################################
*/
