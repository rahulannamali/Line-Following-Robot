/* ###################################################################
**     Filename    : main.c
**     Project     : Projecto
**     Processor   : MKL25Z128VLK4
**     Version     : Driver 01.01
**     Compiler    : GNU C Compiler
**     Date/Time   : 2023-04-12, 17:27, # CodeGen: 0
**     Abstract    :
**         Main module.
**         This module contains user's application code.
**     Settings    :
**     Contents    :
**         No public methods
**
** ###################################################################*/
/*!
** @file main.c
** @version 01.01
** @brief
**         Main module.
**         This module contains user's application code.
*/         
/*!
**  @addtogroup main_module main module documentation
**  @{
*/         
/* MODULE main */


/* Including needed modules to compile this module/procedure */
#include "Cpu.h"
#include "Events.h"
#include "MC1.h"
#include "PwmLdd1.h"
#include "MC2.h"
#include "PwmLdd2.h"
#include "TU1.h"
#include "MC3.h"
#include "PwmLdd3.h"
#include "MC4.h"
#include "PwmLdd4.h"
#include "AD1.h"
#include "AdcLdd1.h"
#include "Servo.h"
#include "PwmLdd5.h"
#include "TU2.h"
#include "CLK.h"
#include "PwmLdd6.h"
#include "TU3.h"
#include "SI.h"
#include "BitIoLdd1.h"
#include "SI_TimerInt.h"
#include "TimerIntLdd1.h"
#include "TU4.h"
#include "HES_TimerInt.h"
#include "TimerIntLdd2.h"
#include "TU5.h"
#include "HES.h"
/* Including shared modules, which are used for whole project */
#include "PE_Types.h"
#include "PE_Error.h"
#include "PE_Const.h"
#include "IO_Map.h"
/* User includes (#include below this line is not maintained by Processor Expert) */
volatile int countawilly = 0;
bool HES = FALSE;
int YOOO;
/*lint -save  -e970 Disable MISRA rule (6.3) checking. */
int main(void)
/*lint -restore Enable MISRA rule (6.3) checking. */
{
  /* Write your local variable definition here */

  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
  PE_low_level_init();
  /*** End of Processor Expert internal initialization.                    ***/

  /* Write your code here */
  for(;;)
  {
	  if(!HES && HES_GetVal(&YOOO))
	  {
		  countawilly++;
		  HES = TRUE;
	  }
	  else if(HES && !HES_GetVal(&YOOO))
	  {
		  HES = FALSE;
		  countawilly++;
	  }




	  //
	  //	 Note the Control might be better inside the main.c?
	  // Bellow this might not be needed; further look through needed
	  //

	  // Start of the Control algorithm for the velocity control
	  // for the control algorithm we need

	  // the Current speed
	  // the desired speed (set-point): these where not measured --> 1V Slow; 2V Fast; 3V Tham
	  /*
	  double Error = 0;
	  double Set_point = 1.0; // this is feet per second
	  double Curr_Speed = velocity;
	  double Desired_Speed = Set_point; // the Set point might be located elsewhere


	  Error = Curr_Speed - Desired_Speed;

	  // Variables for  the motor controllers setratio input
	  int max_ratio = 65535;
	  // motor ratio variables for MCn_SetRatio16()
//	  double mr1 = 0.5;
//	  double mr2 = 1;
//	  double mr3 = 1;
//	  double mr4 = 0.5;
//
	  double mr1_4 = 0.5;
	  double mr2_3 = 1.0;

	  // Proportional controller
	  int kp = 0;
	  int chg = 0;// this is the change  for the motors ratio inputs
	  chg = kp * Error;

	  // this needs some work | I am unsure if it works
	  mr1_4 += chg;
	  mr2_3 -= chg;


//	  	 motor controller variables
	  	 MC4_SetRatio16(mr1_4*max_ratio);
	  	 MC3_SetRatio16(mr2_3*max_ratio);
	  	 MC2_SetRatio16(mr2_3*max_ratio);
	  	 MC1_SetRatio16(mr1_4*max_ratio);


	*/

  }
  /*** Don't write any code pass this line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;){}
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END main */
/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.5 [05.21]
**     for the Freescale Kinetis series of microcontrollers.
**
** ###################################################################
*/
